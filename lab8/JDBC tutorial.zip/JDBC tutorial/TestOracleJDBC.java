import java.sql.*;
import oracle.jdbc.*;
import oracle.jdbc.pool.*;
public class TestOracleJDBC {
	public static void main (String args[]) {
		Connection conn = null;
		String username = "my-user"; // replace with your DB username
		String password = "my-pass"; // replace with your DB password
		String url = "jdbc:oracle:thin:@dbprojects.eecs.qmul.ac.uk:1521:CALVIN";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		} catch (Exception e) {
			System.out.println("Error creating class: "+e.getMessage());
			System.out.println("The Driver was not found, please check driver location, classpath, username/password and server url settings");
			System.exit(0);
		}
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("Error creating connection: "+e.getMessage());
			System.exit(0);
		}
		System.out.println("Closing connections...");
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("Can't close connection.");
		}
	}
}