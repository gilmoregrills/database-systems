//  
// import java packages
// import java.sql.* cause clashes with other java packages

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class JDBCExample {
	public static void main (String args[]) {
		//Modify the URL according to the address of the Oracle server, username, passsword
		String USERNAME = "my-user", PASSWORD = "my-pass";
		String connectURL = "jdbc:oracle:thin:@dbprojects.eecs.qmul.ac.uk:1521:CALVIN";
		Connection db = null; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		} catch (ClassNotFoundException ce) {
			System.out.println("Error class not found: "+ce.getMessage());
			System.exit(0);
		} catch (IllegalAccessException ae) {
			System.out.println("Error illegal access: "+ae.getMessage());
			System.exit(0);
		} catch (InstantiationException ie) {
			System.out.println("Error creating class: "+ie.getMessage());
			System.out.println("The Driver was not found. Please check diver location, classpath, username/password and server url settings");
			System.exit(0);
		}
		
		try {
			db = DriverManager.getConnection(connectURL, USERNAME, PASSWORD);
		} catch (SQLException e) {

		}

		//Create the Statement object, used to execute the SQL statement
		Statement statement = null;              
		//Create the ResultSet object, which ultimately holds the data retrieved
		ResultSet resultset = null;
		//Create the ResultSetMetaData object, which will hold information about the ResultSet
		ResultSetMetaData resultmetadata = null;
		try {
			//This part is not necessary if using an already existing non-empty table
			//Create the table
			System.out.println("Creating PRODUCTS table");
			String createString="CREATE TABLE products (product_id NUMERIC PRIMARY KEY, product_name VARCHAR2(50), base_price FLOAT, product_size NUMERIC, unit VARCHAR2(10), lower NUMERIC, upper NUMERIC, unit_price FLOAT)";
			//System.out.println(createString);
			statement = db.createStatement();
			statement.executeUpdate(createString);
			System.out.println("Insert product 1");
			statement.executeUpdate("insert into products (product_id, product_name, base_price, product_size, unit, lower, upper, unit_price) values ( 1, 'Coke', 0.50 , 10, 'Drink', 10, 100, 0.60)");
			System.out.println("Insert product 2");
			statement.executeUpdate("insert into products (product_id, product_name, base_price, product_size, unit, lower, upper, unit_price) values ( 2, 'Sandwitch', 1.50 , 20, 'Food', 15, 110, 1.60)");
			System.out.println("Insert product 3");
			statement.executeUpdate("insert into products (product_id, product_name, base_price, product_size, unit, lower, upper, unit_price) values ( 3, 'Cheese', 2.50 , 15, 'Food', 20, 120, 2.50)");
			System.out.println("Insert product 4");
			statement.executeUpdate("insert into products (product_id, product_name, base_price, product_size, unit, lower, upper, unit_price) values ( 4, 'Potatoes', 2.70 , 14, 'Vegetable', 30, 130, 2.80)");
			System.out.println("Insert product 5");
			statement.executeUpdate("insert into products (product_id, product_name, base_price, product_size, unit, lower, upper, unit_price) values ( 5, 'Bread', 0.90 , 12, 'Food', 40, 140, 0.90)");
			//end of optional                   

			//Execute the SQL above to populate the ResultSet
			System.out.println("Showing all the products");
			resultset = statement.executeQuery("select * from products");
			//Generic retrieval
			//Get the ResultSet information
			resultmetadata = resultset.getMetaData();
			//Determine the number of columns in the ResultSet
			int numCols = resultmetadata.getColumnCount();
			while (resultset.next()) {
				for (int i=1; i <= numCols; i++) {
					//For each column index, determine the column name
					String colName = resultmetadata.getColumnName(i);
					//Get the column value
					String colVal = resultset.getString(i);
					//if there was no data, add "and up"
					if (resultset.wasNull()){
						colVal = "and up";
					}
					//Output the name and value
					System.out.println(colName+"="+colVal);
				} //end for
				//Output a line feed at the end of the row
				System.out.println("\n");
			} // end of while
		} catch (SQLException e) {
			System.out.println("SQL Error: "+e.getMessage());
		}
		finally {
			System.out.println("Closing connections...");
			try {
				db.close();
			} catch (SQLException e) {
				System.out.println("Can't close connection.");
			}
		} // end finally

		//Because the Statement and Connection are objects, Java will garbage 
		//collect them, freeing up the database resources they take up. This 
		//may lull you into thinking that this means you don't have to worry 
		//about closing these objects, but it's not true. It is entirely possible 
		//that the Java application itself has plenty of resources available, 
		//which means less-frequent garbage collection. It is also possible that 
		//while the Java application has plenty of resources, the available 
		//database resources are limited. Many of the database resources may be 
		//taken up by Java objects that could just as easily have been closed 
		//by the application. It's important to make sure that these objects 
		//are closed whether or not there are any errors, so add a finally 
		//block to the try-catch block that's already in place.Ironically, 
		//the close() method itself can throw a SQLException, so it needs its
		//own try-catch block.
	} // end of main
} // end of class pricing
